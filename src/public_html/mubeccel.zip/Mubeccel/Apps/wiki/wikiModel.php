<?php

class wikiModel extends Model{
    

}

?>