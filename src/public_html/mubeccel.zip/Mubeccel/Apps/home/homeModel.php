<?php 

class homeModel extends Model{

    public static function get_helloworld(){
        return "hello world";
    }
}


?>