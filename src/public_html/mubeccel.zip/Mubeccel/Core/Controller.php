<?php
class Controller{
    public function __construct()
    {
    }
}
?>