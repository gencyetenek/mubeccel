
<div class="row">
    <div class="col-lg">
        
    </div>
    <div class="col-lg-6">
        <?php echo View::$content["name"]; ?>
        <ul class="list-group container mt-4">
            <h3 class="text-left pl-5">Bilgi</h3>
            <li class="list-group-item bg-light pl-5">
                <a class="text-danger" href="/about">
                # Mubeccel Hakkında
                </a>
            </li>
            <li class="list-group-item bg-light pl-5">
                <a class="text-danger" href="/doc/1">
                    Nasıl Çalışır ?
                </a>
            </li>
           
        </ul>
        <ul class="list-group container mt-4">
            <h3 class="text-left pl-5">Yapı</h3>
            
            <li class="list-group-item bg-light pl-5">
                <a class="text-danger" href="/doc/2">
                    Controller
                </a>
            </li>
            <li class="list-group-item bg-light pl-5">
                <a class="text-danger" href="/doc/3">
                    View
                </a>
            </li>
            <li class="list-group-item bg-light pl-5">
                <a class="text-danger" href="/doc/4">
                    Model
                </a>
            </li>
        </ul>


        <ul class="list-group container mt-4">
            <h3 class="text-left pl-5">Sayfa Yönlendirmeleri</h3>
           
            <li class="list-group-item bg-light pl-5">
                <a class="text-danger" href="/doc/5">
                    Routing Sistemi
                </a>
            </li>
           
        </ul>
        

    </div>
    <div class="col-lg">
        
    </div>
</div>