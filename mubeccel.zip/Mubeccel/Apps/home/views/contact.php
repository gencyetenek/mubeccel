<h2>İletişim</h2>
<hr>
<p>
    Selim Can Özdemir
</p>

<p>
    <span class="font-weight-bold">Telegram :</span> <a target="__blank" href="https://t.me/selimcan">@selimcan</a>
</p>
<p>
    <span class="font-weight-bold">Mail :</span> <a href="mailto:ozdemirselimcan@gmail.com">ozdemirselimcan@gmail.com</a>
</p>
<p>
    <span class="font-weight-bold">Github :</span> <a href="https://github.com/selimcanozdemir">selimcanozdemir</a>
</p>
<p>
    <span class="font-weight-bold">Web Sitesi :</span> <a href="https://selimcan.com">selimcan.com</a>
</p>