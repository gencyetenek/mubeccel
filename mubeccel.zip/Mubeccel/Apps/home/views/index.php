
<div class="row">
    <div class="col-lg">
        
    </div>
    <div class="col-lg-6">
        <div class="jumbotron bg-light text-center">
            <img src="/assets/img/logo.png" class="img-fluid" alt="">
            <h1 class="font-weight-light text-center">Lightweight MVC Framework</h1>
            <p class="text-right">by
            <a href="" class="lead text-right text-danger font-weight-light">Selim Can Özdemir</a>
            </p>
            <hr class="my-2">
            <p class="text-left container">
                <h3>Başlarken...</h3>
                <a href="/wiki">Wiki sayfasını görüntülemek için tıklayın.</a>
            </p>
        </div>
    </div>
    <div class="col-lg">
        
    </div>
</div>